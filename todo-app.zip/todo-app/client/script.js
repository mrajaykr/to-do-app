const API = 'http://localhost:5000/api/tasks';

// Load all tasks when page opens
window.onload = () => {
    loadTasks();
};

// Add Task
async function addTask() {

    const title = document.getElementById('title').value.trim();
    const description = document.getElementById('description').value.trim();

    if (title === '' || description === '') {
        alert('Please fill all fields');
        return;
    }

    try {

        await fetch(API, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title,
                description
            })
        });

        document.getElementById('title').value = '';
        document.getElementById('description').value = '';

        loadTasks();

    } catch (error) {
        console.log('Error adding task:', error);
    }
}

// Load Tasks
async function loadTasks() {

    try {

        const response = await fetch(API);
        const tasks = await response.json();

        const taskList = document.getElementById('taskList');

        taskList.innerHTML = '';

        tasks.forEach(task => {

            const taskCard = document.createElement('div');
            taskCard.classList.add('task-card');

            if (task.completed) {
                taskCard.classList.add('completed');
            }

            taskCard.innerHTML = `
                <h3>${task.title}</h3>
                <p>${task.description}</p>

                <div class="task-actions">

                    <button 
                        class="complete-btn"
                        onclick="toggleComplete('${task._id}', ${task.completed})"
                    >
                        ${task.completed ? 'Completed' : 'Complete'}
                    </button>

                    <button 
                        class="delete-btn"
                        onclick="deleteTask('${task._id}')"
                    >
                        Delete
                    </button>

                </div>
            `;

            taskList.appendChild(taskCard);

        });

    } catch (error) {
        console.log('Error loading tasks:', error);
    }
}

// Delete Task
async function deleteTask(id) {

    try {

        await fetch(`${API}/${id}`, {
            method: 'DELETE'
        });

        loadTasks();

    } catch (error) {
        console.log('Error deleting task:', error);
    }
}

// Toggle Complete
async function toggleComplete(id, completed) {

    try {

        await fetch(`${API}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                completed: !completed
            })
        });

        loadTasks();

    } catch (error) {
        console.log('Error updating task:', error);
    }
}
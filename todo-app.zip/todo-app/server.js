const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const taskRoutes = require('./routes/taskRoutes');

const app = express();


// Middleware
app.use(cors());
app.use(express.json());


// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/todoapp')
.then(() => {
    console.log('MongoDB Connected');
})
.catch((err) => {
    console.log('MongoDB Error:', err);
});


// Routes
app.use('/api/tasks', taskRoutes);


// Default Route
app.get('/', (req, res) => {
    res.send('Server Running');
});


// Start Server
app.listen(5000, () => {
    console.log('Server Running on Port 5000');
});